module.exports = {
    MongoURI: 'mongodb+srv://user0:Passw0rd@cluster0.v23ay.mongodb.net/Hackerearth?retryWrites=true&w=majority'
}